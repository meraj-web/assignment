<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
            $this->sentevent();
    }

    public function sentevent()
    {
        $message ='Your message';
        // $url = 'www.your-domain.com/api.php?to='.$mobile.'&text='.$message;
        $url = 'https://api.seatgeek.com/2/events?client_id=Mjc3NDc5NDF8MTY1NzE3NzkzMy43MTU3ODY1';
         
        $ch = curl_init();   
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
        curl_setopt($ch, CURLOPT_URL, $url);   
        $res = curl_exec($ch);   
        // echo $res;   
        // dd($res);
     } 
   
}
