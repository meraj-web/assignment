<?php

namespace App\Http\Controllers;

use App\Models\Events;
use Illuminate\Http\Request;
use DB;

class EventsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        for ($i=1; $i <= 2; $i++) { 
            // $url = 'www.your-domain.com/api.php?to='.$mobile.'&text='.$message;
            $url = 'https://api.seatgeek.com/2/events?client_id=Mjc3NDc5NDF8MTY1NzE3NzkzMy43MTU3ODY1&page='.$i;
            
            $ch = curl_init();   
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
            curl_setopt($ch, CURLOPT_URL, $url);   
            $res = curl_exec($ch);   
            // echo $res;   
            // dd($res);

            $data = json_decode($res);
            // dd($data);
            foreach ($data->events as $key => $event) {
                // dd($event);
                DB::table('events')->insert(['description'=> json_encode($event)]);
            }
            echo "data inserted <br>";
        
        }
       
        
    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Events  $events
     * @return \Illuminate\Http\Response
     */
    public function show(Events $events)
    {
        $alldata = Events::all();
      
        foreach ($alldata as $key => $value) {
            
            $alldata[$key]->description = json_decode(stripslashes(stripslashes($value->description))); 
           
        } 
        // dd($alldata);
        return response()->json([
            'status'=> 'success',
            'data'=> $alldata
        ], 200);
    }


    public function single($id)
    {
        $alldata = Events::find($id);
       if($alldata){
            $alldata->description = json_decode(stripslashes(stripslashes($alldata->description))); 
                
            // dd($alldata);
            return response()->json([
                'status'=> 'success',
                'data'=> $alldata
            ], 200);
       }
        
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Events  $events
     * @return \Illuminate\Http\Response
     */
    public function edit(Events $events)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Events  $events
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Events $events)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Events  $events
     * @return \Illuminate\Http\Response
     */
    public function destroy(Events $events)
    {
        //
    }
}
